This directory contains placeholder audio files for Lab 3.  The files provided here are empty and are meant
to illustrate the expected file structure only.  For your homework you must record or use the supplied
audio samples from the course repository:

  • `clean_speech.mp3` – high quality speech for baseline testing
  • `noisy_background.mp3` – speech with music/noise to test preprocessing
  • `contains_credit_card.mp3` – speech with a fake credit card number for PII detection
  • `fast_speech.mp3` – rapid speech to challenge the recogniser
  • `low_quality_phone.mp3` – low bitrate audio to simulate a phone call

In addition, each student receives a personalised file in the `students/` subfolder named
`test_audio_[YOUR_NAME].mp3`.  Obtain your file from the course materials and place it in this
directory before running the pipeline.