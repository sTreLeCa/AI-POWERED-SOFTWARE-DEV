"""
Simple environment check for Lab 3.

Run this script before starting the lab to verify that you have:
  • Google Cloud credentials configured (Application Default Credentials or service account key).
  • Required Python packages installed.
  • Access to the Speech‑to‑Text and Text‑to‑Speech APIs.

This script does not enable APIs or configure billing.  Follow the instructions in
`docs/google_cloud_setup.md` to complete those steps.
"""

import os
import sys
import importlib
from typing import List

def check_packages(packages: List[str]) -> bool:
    success = True
    for pkg in packages:
        try:
            importlib.import_module(pkg)
            print(f"✅ Package available: {pkg}")
        except ImportError:
            print(f"❌ Package missing: {pkg}")
            success = False
    return success


def check_credentials() -> bool:
    try:
        from google.auth import default  # type: ignore
        credentials, project = default()
        print(f"✅ Credentials loaded.  Project: {project or 'unknown'}")
        return True
    except Exception as e:
        print(f"❌ Failed to load Google Cloud credentials: {e}")
        return False


def check_api_access() -> bool:
    try:
        from google.cloud import speech  # type: ignore
        from google.cloud import texttospeech  # type: ignore
        # Attempt to instantiate clients
        speech.SpeechClient()
        texttospeech.TextToSpeechClient()
        print("✅ Able to create Speech and Text‑to‑Speech clients")
        return True
    except Exception as e:
        print(f"❌ Unable to create API clients: {e}")
        return False


def main() -> None:
    print("Running Lab 3 environment check…")
    print("\nChecking required Python packages…")
    packages_ok = check_packages([
        'google.cloud.speech',
        'google.cloud.texttospeech',
        'librosa',
        'numpy',
        'pydub',
        'spacy'
    ])

    print("\nChecking Google Cloud credentials…")
    creds_ok = check_credentials()

    print("\nChecking API client access…")
    api_ok = check_api_access()

    all_ok = packages_ok and creds_ok and api_ok
    if all_ok:
        print("\n✅ Environment looks ready.  You can start the lab.")
        sys.exit(0)
    else:
        print("\n⚠️  One or more checks failed.  Fix the issues above before proceeding.")
        sys.exit(1)


if __name__ == '__main__':
    main()