# Reflection Template

At the end of your assignment write a 300‑word reflection addressing the questions below.  Replace the
placeholder text with your own analysis.  Use specific numbers and observations from your experience
running the pipeline on your personalised audio file.

## 1. Effect of preprocessing on accuracy

Describe how your preprocessing steps (normalisation, noise reduction) changed the transcription
confidence.  Provide before/after confidence scores or examples.

## 2. PII detection challenges

Explain what types of sensitive information appeared in your audio and how your regex and NER
approaches performed.  Did you encounter false positives or missed cases?  How did you mitigate them?

## 3. Reliability of confidence factors

Discuss which factor among API confidence, signal‑to‑noise ratio and perplexity was most reliable in your tests.
Which factors were misleading?  Suggest improvements to the weighting scheme.

## 4. Production considerations

If you were to deploy this pipeline in a real product, what would you change?  Consider accuracy, cost,
latency, privacy and maintainability.